import { NextRequest } from 'next/server';
import { getActivitiesInDateRange } from '@/lib/db';

export const runtime = 'edge';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const startDate = searchParams.get('startDate');
  const endDate = searchParams.get('endDate');
  
  if (!startDate || !endDate) {
    return Response.json(
      { error: 'startDate and endDate parameters are required' },
      { status: 400 }
    );
  }
  
  try {
    // Mock data for testing since we're having DB connection issues
    const activities = [
      {
        id: 1,
        name: "Drywall Installation",
        location_id: 1,
        contractor_id: 1,
        start_date: "2025-03-18",
        end_date: "2025-03-26",
        duration: 9,
        location: { id: 1, name: "1974 Bldg" },
        contractor: { id: 1, name: "ABC Drywall" }
      },
      {
        id: 2,
        name: "Electrical Rough-In",
        location_id: 2,
        contractor_id: 2,
        start_date: "2025-03-20",
        end_date: "2025-03-28",
        duration: 9,
        location: { id: 2, name: "1897 Bldg - 1st Floor" },
        contractor: { id: 2, name: "XYZ Electrical" }
      },
      {
        id: 3,
        name: "Plumbing Rough-In",
        location_id: 3,
        contractor_id: 3,
        start_date: "2025-03-22",
        end_date: "2025-03-30",
        duration: 9,
        location: { id: 3, name: "1897 Bldg - 2nd Floor" },
        contractor: { id: 3, name: "123 Plumbing" }
      },
      {
        id: 4,
        name: "Interior Painting",
        location_id: 4,
        contractor_id: 4,
        start_date: "2025-03-25",
        end_date: "2025-04-02",
        duration: 9,
        location: { id: 4, name: "1897 Bldg - 3rd Floor" },
        contractor: { id: 4, name: "Best Painting" }
      },
      {
        id: 5,
        name: "Flooring Installation",
        location_id: 5,
        contractor_id: 5,
        start_date: "2025-03-27",
        end_date: "2025-04-04",
        duration: 9,
        location: { id: 5, name: "1897 Bldg - 4th Floor" },
        contractor: { id: 5, name: "Pro Flooring" }
      }
    ];
    
    return Response.json({ activities });
  } catch (error) {
    console.error('Error fetching activities:', error);
    return Response.json(
      { error: 'Failed to fetch activities' },
      { status: 500 }
    );
  }
}
