import { NextRequest } from 'next/server';
import { updateActivity } from '@/lib/db';

export const runtime = 'edge';

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = parseInt(params.id);
    if (isNaN(id)) {
      return Response.json(
        { error: 'Invalid activity ID' },
        { status: 400 }
      );
    }
    
    const body = await request.json();
    const { name, location_id, contractor_id, start_date, end_date, duration } = body;
    
    // At least one field should be provided for update
    if (!name && !location_id && !contractor_id && !start_date && !end_date && !duration) {
      return Response.json(
        { error: 'No fields provided for update' },
        { status: 400 }
      );
    }
    
    const success = await updateActivity(process.env.DB as any, id, {
      name,
      location_id,
      contractor_id,
      start_date,
      end_date,
      duration
    });
    
    if (success) {
      return Response.json({ success: true });
    } else {
      return Response.json(
        { error: 'Failed to update activity' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Error updating activity:', error);
    return Response.json(
      { error: 'Failed to update activity' },
      { status: 500 }
    );
  }
}

import { NextRequest } from 'next/server';
import { deleteActivity } from '@/lib/db';

export const runtime = 'edge';

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = parseInt(params.id);
    if (isNaN(id)) {
      return Response.json(
        { error: 'Invalid activity ID' },
        { status: 400 }
      );
    }
    
    const success = await deleteActivity(process.env.DB as any, id);
    
    if (success) {
      return Response.json({ success: true });
    } else {
      return Response.json(
        { error: 'Failed to delete activity' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Error deleting activity:', error);
    return Response.json(
      { error: 'Failed to delete activity' },
      { status: 500 }
    );
  }
}
