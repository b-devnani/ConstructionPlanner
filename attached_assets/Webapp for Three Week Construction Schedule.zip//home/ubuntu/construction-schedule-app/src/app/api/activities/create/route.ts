import { NextRequest } from 'next/server';
import { createActivity } from '@/lib/db';

export const runtime = 'edge';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, location_id, contractor_id, start_date, end_date, duration } = body;
    
    // Validate required fields
    if (!name || !location_id || !contractor_id || !start_date || !end_date || !duration) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }
    
    const success = await createActivity(process.env.DB as any, {
      name,
      location_id,
      contractor_id,
      start_date,
      end_date,
      duration
    });
    
    if (success) {
      return Response.json({ success: true });
    } else {
      return Response.json(
        { error: 'Failed to create activity' },
        { status: 500 }
      );
    }
  } catch (error) {
    console.error('Error creating activity:', error);
    return Response.json(
      { error: 'Failed to create activity' },
      { status: 500 }
    );
  }
}
